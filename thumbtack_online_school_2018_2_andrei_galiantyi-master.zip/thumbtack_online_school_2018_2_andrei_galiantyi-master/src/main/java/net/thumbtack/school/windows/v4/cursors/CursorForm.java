package net.thumbtack.school.windows.v4.cursors;

public enum CursorForm {
    ARROW, UPARROW, CROSS, HELP, WAIT
}
