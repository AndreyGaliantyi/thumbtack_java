package net.thumbtack.school.windows.v3.iface;

public interface Resizable {

    void resize(double ratio);
}
